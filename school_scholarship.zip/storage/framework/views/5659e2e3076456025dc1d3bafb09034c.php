<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"
    integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

<script src="https://code.jquery.com/jquery-3.7.0.min.js"
    integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
    integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<?php if(Session::has('success')): ?>
<script>
    toastr.success("<?php echo e(Session::get('success')); ?>");
</script>
<?php
Session::forget('success')
?>
<?php endif; ?>


<?php if(Session::has('info')): ?>
<script>
    toastr.info("<?php echo e(Session::get('info')); ?>");
</script>
<?php endif; ?>


<?php if(Session::has('warning')): ?>
<script>
    toastr.warning("<?php echo e(Session::get('warning')); ?>");
</script>
<?php endif; ?>


<?php if(Session::has('error')): ?>
<script>
    toastr.error("<?php echo e(Session::get('error')); ?>");
</script>
<?php endif; ?>
<?php /**PATH I:\school_scholarship\resources\views/admin/_partials/notification.blade.php ENDPATH**/ ?>