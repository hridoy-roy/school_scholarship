<div <?php echo e($attributes->merge(['class' => 'w-100'])); ?>>
    <label class="form-label-lg mx-3" for="formValidation<?php echo e($label); ?>"><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>" id="formValidation<?php echo e($label); ?>"
        class="form-control rounded-pill form-control-lg <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if($required): ?> required
        <?php endif; ?> placeholder="<?php echo e($placeholder); ?>" value="<?php echo e(old($name) ?? $value); ?>" name="<?php echo e($name); ?>" />
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH I:\school_scholarship\resources\views/components/input.blade.php ENDPATH**/ ?>