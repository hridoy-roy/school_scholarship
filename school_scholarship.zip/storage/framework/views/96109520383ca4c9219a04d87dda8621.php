<!-- laravel style -->
<script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>

<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
<?php /**PATH I:\school_scholarship\resources\views/admin/layouts/sections/scriptsIncludes.blade.php ENDPATH**/ ?>