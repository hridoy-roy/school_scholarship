<?php $__env->startSection('main-container'); ?>
<!-- Blog Section -->
<section id="blog" class="blog">
    <div class="container-fluid">
        <div class="row">
            <div class="main_blog sections">
                <div class="head_title text-center">
                    <h2>OUR BLOG</h2>
                    <div class="subtitle">
                        Suspendisse sed eros mollis, tincidunt felis eget, interdum eratullam sit amet odio.
                    </div>
                    <div class="separator"></div>
                </div><!-- End off Head_title -->

                <div class="main_blog_content">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6">
                        <div class="single_blog_area textwhite">
                            <div class="row">
                                <div class="col-sm-6 no-padding">
                                    <div class="single_blog_img">
                                        <img src="<?php echo e(asset('upload/blog/'.$blog->banner)); ?>" alt="" />
                                    </div>
                                </div>
                                <div class="col-sm-6 no-padding">
                                    <div class="single_blog_text s_b_left">
                                        <p><?php echo e($blog->slug); ?></p>
                                        <h3><?php echo e($blog->title); ?></h3>
                                        <div class="separator2"></div>
                                        <p>
                                            <?php echo Str::words($blog->body, 30, '...'); ?>

                                        </p>

                                    </div>
                                    <a href="<?php echo e(url('blog').'/'.$blog->slug); ?>" class="read_more">Read More >></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
        </div>
    </div>
</section>
<!-- End off Blog Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\school_scholarship\resources\views/frontend/blog.blade.php ENDPATH**/ ?>