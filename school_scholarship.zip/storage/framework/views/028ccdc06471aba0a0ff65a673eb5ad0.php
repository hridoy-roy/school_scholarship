<?php $__env->startSection('main-container'); ?>
<!-- Blog Section -->
<section id="blog" class="blog">
    <div class="container">
        <div class="row">
            <div class="main_blog sections">
                <div class="head_title text-center">
                    <h2>BLOG Details</h2>
                    <div class="">
                        <h4><?php echo e($blog->title); ?></h4>
                        <?php echo e(\Carbon\Carbon::parse($blog->created_at)->diffForHumans()); ?>

                    </div>
                    <div class="separator"></div>
                </div><!-- End off Head_title -->

                <div class="main_blog_content">

                    <?php echo $blog->body; ?>

                </div>

            </div>
        </div>
    </div>
</section>
<!-- End off Blog Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\school_scholarship\resources\views/frontend/blog-details.blade.php ENDPATH**/ ?>