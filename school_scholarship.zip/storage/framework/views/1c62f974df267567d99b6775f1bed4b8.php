<?php $__env->startSection('title', 'Institute'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between my-2">
    <h4 class="fw-bold">
        <span class="text-muted fw-light"><?php echo e($title ?? 'N/A'); ?> /</span> <?php echo e($sub_title ?? 'N/A'); ?>

    </h4>
    <a href="<?php echo e(route('institute.create')); ?>"> <button class=" btn btn-primary">➥ Create</button></a>
</div>
<div class="card">
    <h5 class="card-header">Create Institute</h5>
    <div class="table-responsive text-nowrap">
        <table class="table">
        <thead>
            <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Order By</th>                      
            <th>Institute Status</th>
            <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $sl=1 
            ?>

            <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($sl++); ?></td>
            <td><?php echo e($institute->name); ?></td>
            <td><?php echo e($institute->order_by); ?></td>
            <td><span class="badge bg-label-primary me-1"><?php echo e($institute->status == 1 ? 'Active' : 'Inactive'); ?></span></td>
            <td>
                <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                    <i class="ti ti-dots-vertical"></i>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo e(route('institute.edit',$institute->id)); ?>"><i class="ti ti-pencil me-1"></i> Edit</a>
                    <form method="post" id="<?php echo e('form_'.$institute->id); ?>" action="<?php echo e(route('institute.destroy',$institute->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="dropdown-item" data-id="<?php echo e($institute->id); ?>"><i class="ti ti-trash me-1"></i> Delete</button>
                    </form>
                </div>
                </div>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="table-border-bottom-0">
            <tr>
            <th class="rounded-start-bottom">ID</th>
            <th>Name</th>
            <th>Order By</th>                      
            <th>Institute Status</th>
            <th class="rounded-end-bottom">Actions</th>
            </tr>
        </tfoot>
        </table>          
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\school_scholarship\resources\views/admin/content/institute/index.blade.php ENDPATH**/ ?>