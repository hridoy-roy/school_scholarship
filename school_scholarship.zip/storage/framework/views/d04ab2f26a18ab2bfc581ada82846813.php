<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

    <!-- ! Hide app brand if navbar-full -->

    <div class="app-brand demo">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo">
                <?php echo $__env->make('admin._partials.macros',["height"=>20], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </span>
            <span class="app-brand-text demo menu-text fw-bold"><?php echo e(config('variables.templateName')); ?></span>
        </a>

        <a href="<?php echo e(route('admin.dashboard')); ?>" class="layout-menu-toggle menu-link text-large ms-auto">
            <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
            <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
        </a>
    </div>


    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <li class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?> menu-item">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons ti ti-smart-home"></i>
                <div data-i18n="Dashboards">Dashboards</div>
            </a>
        </li>
        <?php if(auth()->user()->is_admin == 1): ?>
        <li
            class="<?php echo e(request()->routeIs('classes.index') || request()->routeIs('classes.create') || request()->routeIs('classes.edit') ? 'active open' : ''); ?> menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon ti ti-school"></i>
                <div data-i18n="Dashboards">Institute</div>
                <div class="badge bg-label-primary rounded-pill ms-auto">2</div>
            </a>
            <ul class="menu-sub">
                <li class="<?php echo e(request()->routeIs('classes.index') ? 'active' : ''); ?> menu-item">
                    <a href="<?php echo e(route('institute.index')); ?>" class="menu-link">
                        <div>List</div>
                    </a>
                </li>
                <li class="<?php echo e(request()->routeIs('classes.create') ? 'active' : ''); ?> menu-item">
                    <a href="<?php echo e(route('institute.create')); ?>" class="menu-link">
                        <div>Create</div>
                    </a>
                </li>
            </ul>
        </li>
        <li
            class="<?php echo e(request()->routeIs('classes.index') || request()->routeIs('classes.create') || request()->routeIs('classes.edit') ? 'active open' : ''); ?> menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon ti ti-server"></i>
                <div data-i18n="Dashboards">Class</div>
                <div class="badge bg-label-primary rounded-pill ms-auto">2</div>
            </a>
            <ul class="menu-sub">
                <li class="<?php echo e(request()->routeIs('classes.index') ? 'active' : ''); ?> menu-item">
                    <a href="<?php echo e(route('classes.index')); ?>" class="menu-link">
                        <div>List</div>
                    </a>
                </li>
                <li class="<?php echo e(request()->routeIs('classes.create') ? 'active' : ''); ?> menu-item">
                    <a href="<?php echo e(route('classes.create')); ?>" class="menu-link">
                        <div>Create</div>
                    </a>
                </li>
            </ul>
        </li>
        <li
            class="<?php echo e(request()->routeIs('blogs.index') || request()->routeIs('blogs.create') || request()->routeIs('blogs.edit') || request()->routeIs('blogs.show') ? 'active open' : ''); ?> menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-smart-home"></i>
                <div data-i18n="Dashboards">Blogs</div>
                <div class="badge bg-label-primary rounded-pill ms-auto">2</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('blogs.index')); ?>"
                        class="<?php echo e(request()->routeIs('blogs.index') ? 'active' : ''); ?> menu-link">
                        <div>List</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="<?php echo e(route('blogs.create')); ?>"
                        class="<?php echo e(request()->routeIs('blogs.create') ? 'active' : ''); ?> menu-link">
                        <div>Create</div>
                    </a>
                </li>
            </ul>
        </li>
        <li
            class="<?php echo e(request()->routeIs('users.index') || request()->routeIs('users.create') || request()->routeIs('users.edit') || request()->routeIs('users.show') ? 'active open' : ''); ?> menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-smart-home"></i>
                <div data-i18n="Dashboards">Admin</div>
                <div class="badge bg-label-primary rounded-pill ms-auto">2</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('users.index')); ?>"
                        class="<?php echo e(request()->routeIs('users.index') ? 'active' : ''); ?> menu-link">
                        <div>List</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="<?php echo e(route('users.create')); ?>"
                        class="<?php echo e(request()->routeIs('users.create') ? 'active' : ''); ?> menu-link">
                        <div>Create</div>
                    </a>
                </li>
            </ul>
        </li>
        <?php endif; ?>
        <li
            class="<?php echo e(request()->routeIs('blogs.index') || request()->routeIs('blogs.create') || request()->routeIs('blogs.edit') || request()->routeIs('blogs.show') ? 'active open' : ''); ?> menu-item">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-smart-home"></i>
                <div data-i18n="Dashboards">Result</div>
                <div class="badge bg-label-primary rounded-pill ms-auto">2</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('blogs.index')); ?>"
                        class="<?php echo e(request()->routeIs('blog.index') ? 'active' : ''); ?> menu-link">
                        <div>List</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="<?php echo e(route('blogs.create')); ?>"
                        class="<?php echo e(request()->routeIs('blog.create') ? 'active' : ''); ?> menu-link">
                        <div>Create</div>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</aside>
<?php /**PATH I:\school_scholarship\resources\views/admin/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>