<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
    <div class="{{ (!empty($containerNav) ? $containerNav : 'container-fluid') }}">
        <div class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
            <div>
                © <script>
                    document.write(new Date().getFullYear())

                </script>
                , made with ❤️ by <a href="#" target="_blank" class="fw-semibold">Hridoy Roy</a>
            </div>
            <div>

            </div>
        </div>
    </div>
</footer>
<!--/ Footer-->