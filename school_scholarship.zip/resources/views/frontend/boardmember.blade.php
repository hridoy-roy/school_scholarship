<!--feature section -->

    <section id="feature" class="feature sections">
        <div class="container">
            <div class="row">
                <div class="main_feature text-center">

                    <div class="col-sm-3">
                        <div class="single_feature">
                            <div class="single_feature_icon">
                                <i class="fa fa-clone"></i>
                            </div>

                            <h4>SLEEK DESIGN</h4>
                            <div class="separator3"></div>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting let.
                                Lorem Ipsum has been the industry.</p>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="single_feature">
                            <div class="single_feature_icon">
                                <i class="fa fa-heart-o"></i>
                            </div>

                            <h4>CLEAN CODE</h4>
                            <div class="separator3"></div>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting let.
                                Lorem Ipsum has been the industry.</p>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="single_feature">
                            <div class="single_feature_icon">
                                <i class="fa fa-lightbulb-o"></i>
                            </div>
                            <h4>CREATIVE IDEAS</h4>
                            <div class="separator3"></div>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting let.
                                Lorem Ipsum has been the industry.</p>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="single_feature">
                            <div class="single_feature_icon">
                                <i class="fa fa-comments-o"></i>
                            </div>

                            <h4>FREE SUPPORT</h4>
                            <div class="separator3"></div>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting let.
                                Lorem Ipsum has been the industry.</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
        
<!--End of feature Section -->
<hr />