<!-- Client Logo Section -->

    <section id="clogo" class="clogo">
        <div class="container">
            <div class="row">
                <div class="main_clogo sections text-center">
                    <div class="head_title text-center">
                        <h2>Great Integrations with Others</h2>
                        <div class="subtitle">
                            Suspendisse sed eros mollis, tincidunt felis eget, interdum erat.
                            Nullam sit amet odio eu est aliquet euismod a a urna. Proin eu urna suscipit, dictum
                            quam nec.
                        </div>
                        <div class="separator"></div>
                    </div><!-- End off Head_title -->

                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo1.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo2.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo3.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo4.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo5.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo6.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo9.png" alt="" /></a>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <a href=""><img src="assets/images/clogo8.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="divider"></div>
    </section>

<!-- End off clogo Section -->