<!--home Section -->

    <section id="home" class="home">
        <div class="overlay">
            <div class="home_skew_border">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 ">
                            <div class="main_home_slider text-center">
                                <div class="single_home_slider">
                                    <div class="main_home wow fadeInUp" data-wow-duration="700ms">
                                        <h3>Our Clients Are Our First Priority</h3>
                                        <h1>WELCOME TO BINO</h1>
                                        <div class="separator"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                            industry. Lorem Ipsum has been the industry's
                                            standard dummy text ever since the 1500s, when an unknown printer took a
                                            galley
                                            of type and scrambled it to make a type specimen book.</p>
                                        <div class="home_btn">
                                            <a href="https://bootstrapthemes.co" class="btn btn-lg m_t_10">GET
                                                STARTED NOW</a>
                                            <a href="https://bootstrapthemes.co" class="btn btn-default">LEARN
                                                MORE</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="single_home_slider">
                                    <div class="main_home wow fadeInUp" data-wow-duration="700ms">
                                        <h3>Our Clients Are Our First Priority</h3>
                                        <h1>WELCOME TO BINO</h1>
                                        <div class="separator"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                            industry. Lorem Ipsum has been the industry's
                                            standard dummy text ever since the 1500s, when an unknown printer took a
                                            galley
                                            of type and scrambled it to make a type specimen book.</p>
                                        <div class="home_btn">
                                            <a href="https://bootstrapthemes.co" class="btn btn-lg m_t_10">GET
                                                STARTED NOW</a>
                                            <a href="https://bootstrapthemes.co" class="btn btn-default">LEARN
                                                MORE</a>
                                        </div>

                                    </div>
                                </div>
                                <div class="single_home_slider">
                                    <div class="main_home wow fadeInUp" data-wow-duration="700ms">
                                        <h3>Our Clients Are Our First Priority</h3>
                                        <h1>WELCOME TO BINO</h1>
                                        <div class="separator"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                            industry. Lorem Ipsum has been the industry's
                                            standard dummy text ever since the 1500s, when an unknown printer took a
                                            galley
                                            of type and scrambled it to make a type specimen book.</p>
                                        <div class="home_btn">
                                            <a href="https://bootstrapthemes.co" class="btn btn-lg m_t_10">GET
                                                STARTED NOW</a>
                                            <a href="https://bootstrapthemes.co" class="btn btn-default">LEARN
                                                MORE</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="scrooldown">
                    <a href="#feature"><i class="fa fa-arrow-down"></i></a>
                </div>
            </div>
        </div>
    </section>

<!--End of home section -->