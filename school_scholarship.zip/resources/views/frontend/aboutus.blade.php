@extends('frontend.layouts.main')

@section('main-container')

<!-- History section -->

    <section id="history" class="history sections">
        <div class="container">
            <div class="row">
                <div class="main_history">
                    <div class="col-sm-6">
                        <div class="single_history_img">
                            <img src="assets/images/stab1.png" alt="" />
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="single_history_content">
                            <div class="head_title">
                                <h2>OUR HISTORY</h2>
                            </div>
                            <p>It is a long established fact that a reader will be distracted by the readable
                                content of a page
                                when looking at its layout. The point of using Lorem Ipsum is that it has a
                                more-or-less normal
                                distribution of letters, as opposed to using 'Content here, content here', making it
                                look like readable English. Many desktop publishing packages and web page editors
                                now use
                                Lorem Ipsum as their default model text, and a search for 'lorem ipsum' </p>

                            <a href="" class="btn btn-lg">BROWSE OUR WORK</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!--End of history -->

@endsection
